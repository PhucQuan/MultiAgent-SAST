# OWASP Benchmark Score

- Target: `C:\2026-2027\NCKH\owasp-benchmark-python`
- Files scanned: 1239
- Scan runtime (seconds): 31.4487
- Report findings: 144
- Expected cases loaded: 1230
- Expected cases scored: 258
- Families: COMMAND_INJECTION, PATH_TRAVERSAL, INSECURE_DESERIALIZATION, SQL_INJECTION

## FP Reduction vs all

| Metric | Value |
|---|---:|
| FP reduction (visible) | 100.0000% |
| FP reduction (high-confidence) | 100.0000% |

## Mode: all

| Metric | Value |
|---|---:|
| Findings kept | 95 |
| TP | 85 |
| FP | 10 |
| FN | 16 |
| Precision | 0.8947 |
| Recall | 0.8416 |
| F1 | 0.8673 |

| Family | Expected True | Expected False | Detected | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `COMMAND_INJECTION` | 13 | 7 | 17 | 13 | 4 | 0 | 0.7647 | 1.0000 | 0.8667 |
| `PATH_TRAVERSAL` | 65 | 103 | 52 | 52 | 0 | 13 | 1.0000 | 0.8000 | 0.8889 |
| `INSECURE_DESERIALIZATION` | 18 | 36 | 21 | 15 | 6 | 3 | 0.7143 | 0.8333 | 0.7692 |
| `SQL_INJECTION` | 5 | 11 | 5 | 5 | 0 | 0 | 1.0000 | 1.0000 | 1.0000 |

- `COMMAND_INJECTION` FP cases: BenchmarkTest00350, BenchmarkTest00512, BenchmarkTest00736, BenchmarkTest00900
- `COMMAND_INJECTION` FN cases: none
- `PATH_TRAVERSAL` FP cases: none
- `PATH_TRAVERSAL` FN cases: BenchmarkTest00092, BenchmarkTest00182, BenchmarkTest00526, BenchmarkTest00906, BenchmarkTest00907, BenchmarkTest00910, BenchmarkTest00914, BenchmarkTest00915, BenchmarkTest00916, BenchmarkTest00918, BenchmarkTest00920, BenchmarkTest01192, BenchmarkTest01214
- `INSECURE_DESERIALIZATION` FP cases: BenchmarkTest00349, BenchmarkTest00508, BenchmarkTest00513, BenchmarkTest00608, BenchmarkTest00658, BenchmarkTest00826
- `INSECURE_DESERIALIZATION` FN cases: BenchmarkTest00992, BenchmarkTest00993, BenchmarkTest00994
- `SQL_INJECTION` FP cases: none
- `SQL_INJECTION` FN cases: none

## Mode: visible

| Metric | Value |
|---|---:|
| Findings kept | 85 |
| TP | 85 |
| FP | 0 |
| FN | 16 |
| Precision | 1.0000 |
| Recall | 0.8416 |
| F1 | 0.9140 |

| Family | Expected True | Expected False | Detected | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `COMMAND_INJECTION` | 13 | 7 | 13 | 13 | 0 | 0 | 1.0000 | 1.0000 | 1.0000 |
| `PATH_TRAVERSAL` | 65 | 103 | 52 | 52 | 0 | 13 | 1.0000 | 0.8000 | 0.8889 |
| `INSECURE_DESERIALIZATION` | 18 | 36 | 15 | 15 | 0 | 3 | 1.0000 | 0.8333 | 0.9091 |
| `SQL_INJECTION` | 5 | 11 | 5 | 5 | 0 | 0 | 1.0000 | 1.0000 | 1.0000 |

- `COMMAND_INJECTION` FP cases: none
- `COMMAND_INJECTION` FN cases: none
- `PATH_TRAVERSAL` FP cases: none
- `PATH_TRAVERSAL` FN cases: BenchmarkTest00092, BenchmarkTest00182, BenchmarkTest00526, BenchmarkTest00906, BenchmarkTest00907, BenchmarkTest00910, BenchmarkTest00914, BenchmarkTest00915, BenchmarkTest00916, BenchmarkTest00918, BenchmarkTest00920, BenchmarkTest01192, BenchmarkTest01214
- `INSECURE_DESERIALIZATION` FP cases: none
- `INSECURE_DESERIALIZATION` FN cases: BenchmarkTest00992, BenchmarkTest00993, BenchmarkTest00994
- `SQL_INJECTION` FP cases: none
- `SQL_INJECTION` FN cases: none

## Mode: high-confidence

| Metric | Value |
|---|---:|
| Findings kept | 73 |
| TP | 73 |
| FP | 0 |
| FN | 28 |
| Precision | 1.0000 |
| Recall | 0.7228 |
| F1 | 0.8391 |

| Family | Expected True | Expected False | Detected | TP | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `COMMAND_INJECTION` | 13 | 7 | 13 | 13 | 0 | 0 | 1.0000 | 1.0000 | 1.0000 |
| `PATH_TRAVERSAL` | 65 | 103 | 40 | 40 | 0 | 25 | 1.0000 | 0.6154 | 0.7619 |
| `INSECURE_DESERIALIZATION` | 18 | 36 | 15 | 15 | 0 | 3 | 1.0000 | 0.8333 | 0.9091 |
| `SQL_INJECTION` | 5 | 11 | 5 | 5 | 0 | 0 | 1.0000 | 1.0000 | 1.0000 |

- `COMMAND_INJECTION` FP cases: none
- `COMMAND_INJECTION` FN cases: none
- `PATH_TRAVERSAL` FP cases: none
- `PATH_TRAVERSAL` FN cases: BenchmarkTest00008, BenchmarkTest00087, BenchmarkTest00089, BenchmarkTest00092, BenchmarkTest00180, BenchmarkTest00182, BenchmarkTest00357, BenchmarkTest00444, BenchmarkTest00445, BenchmarkTest00523, BenchmarkTest00526, BenchmarkTest00742, BenchmarkTest00834, BenchmarkTest00835, BenchmarkTest00906, BenchmarkTest00907, BenchmarkTest00910, BenchmarkTest00914, BenchmarkTest00915, BenchmarkTest00916
- `INSECURE_DESERIALIZATION` FP cases: none
- `INSECURE_DESERIALIZATION` FN cases: BenchmarkTest00992, BenchmarkTest00993, BenchmarkTest00994
- `SQL_INJECTION` FP cases: none
- `SQL_INJECTION` FN cases: none
